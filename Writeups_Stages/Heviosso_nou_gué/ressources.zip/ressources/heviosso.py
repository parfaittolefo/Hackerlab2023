from PIL import Image

image_paths = []

for i in range(625):
    num = str(i).zfill(3)
    image_paths.append('frame_'+str(num)+'_delay-0.05s.gif')



images = [Image.open(path).convert("RGBA") for path in image_paths]

width, height = images[0].size

combined_image = Image.new("RGBA", (width, height), (0, 0, 0, 0))

for image in images:
    mask = Image.new("L", image.size, 255)
    mask.paste(image, (0, 0), image)

    image = Image.composite(image, Image.new("RGBA", image.size, (0, 0, 0, 0)), mask)

    combined_image = Image.alpha_composite(combined_image, image)

combined_image.save("combined_image.png")
